library(mvtnorm)
library(statmod)
library(GIGrvg)
library(MCMCpack)
library(SphericalCubature)
library(glmnet)

polrec <- function(angl, r =1){
  len  <- length(angl)
  temp <- exp(cumsum(log(sin(angl[1:(len-1)]))))
  temp <- c(1, temp)
  
  temp[1:len] <- temp[1:len] * cos(angl)
  temp <- c(temp, prod(sin(angl)))
  return(r * temp)
}

HMClin = function (U = Ulin, grad_U = grad_Ulin, epsilon, L = 30, current_q, ard, Y, X, sigma, bsigma)
{
  q = current_q
  po = rnorm(length(q),0,1)  # independent standard normal variates
  current_p = po
  
  # Make a half step for momentum at the beginning
  
  po = po - epsilon * grad_U(q, Y, X, sigma, bsigma) / 2
  
  # Alternate full steps for position and momentum
  
  for (j in 1:L)
  {
    # Make a full step for the position
    
    q = q + epsilon * po
    
    # Make a full step for the momentum, except at end of trajectory
    
    if (j!=L) po = po - epsilon * grad_U(q, Y, X, sigma, bsigma)
  }
  
  # Make a half step for momentum at the end.
  
  po = po - epsilon * grad_U(q, Y, X, sigma, bsigma) / 2
  
  # Negate momentum at end of trajectory to make the proposal symmetric
  
  po = -po
  
  # Evaluate potential and kinetic energies at start and end of trajectory
  
  current_U = U(current_q, Y, X, sigma, bsigma)
  current_K = sum(current_p^2) / 2
  proposed_U = U(q, Y, X, sigma, bsigma)
  proposed_K = sum(po^2) / 2
  
  # Accept or reject the state at end of trajectory, returning either
  # the position at the end of the trajectory or the initial position
  
  if (runif(1) < exp(current_U-proposed_U+current_K-proposed_K))
  {
    ard <- ard + 1
    return (list(up=q, ard = ard))  # accept
  }
  else
  {
    return (list(up=current_q, ard = ard))  # reject
  }
}

Ulin <- function(beta, Y, X, sigma, bsigma){
  ret <- sum((Y-X %*%beta)^2) / sigma^2 + sum((beta/bsigma)^2) 
  return(ret / 2)
}

grad_Ulin <- function(delta, Y, X, sigma, bsigma){
  ret <- -t(X) %*% (Y-X %*%beta) / sigma^2 + beta/bsigma^2
  return(ret)
}

#################################Function HSIM##########################
#' @title The function to fit the model Y = X'beta + Z'theta using horseshoe prior on beta
#' @description Takes the response variable, explanatory variables (high and low dimensional) and some
#' other tuning parameters and spits out MCMC samples of beta and eta and other hyper parameters 
#' @references Carvalho, Carlos M., Nicholas G. Polson, and James G. Scott. "The horseshoe estimator for sparse signals.
#' " Biometrika 97.2 (2010): 465-480.
#'
#' @param Y response variable
#' @param X is high dimensional explanatory variable
#' @param Z is low dimensional explanatory variable
#' @param method.tau is the method to sample tau among the options "fixed", "truncatedCauchy" and "halfCauchy" 
#' @param tau is the initial parameter tau from the prior
#' @param glmnetid is the indicator variable if initialization is done via LASSO optimization
#' @param burn is the number of burn-in samples
#' @parma Total_itr is the total number of samples
#' @param thin is the integer that is thinning parameter of MCMC chain
#' @param L1 is the leapfrog step of the HMC sampler
#' @param fixed.var is the prior variance for coefficients of B-spline
#' @param acl is the lower acceptance level of the HMC sampler
#' @param acu is the upper acceptance level of the HMC sampler

#' @return horseshoe returns a list of the following elements \cr
#' \item{beta_post}{Posterior samples of beta}
#' \item{lambda_post}{Posterior samples of phi from the horseshoe prior}

#' \item{tau_post}{Posterior samples of tau from the horseshoe prior}
#' \item{theta_post}{Posterior samples of theta}
#'
#'
#' @export
#' @examples
#' angl0 <- runif(49, 0, pi)
#' beta <- polrec(angl0)
#' theta <- rnorm(11)
#' X <- matrix(rnorm(5000), 100)
#' Y <- rnorm(sin(crossprod(t(X), beta)))
#' sigma0 <- 1
#' fit <- horseshoe(Y, X)
#'
horseshoe <- function(Y, X, Z = NULL, method.tau = c("fixed", "truncatedCauchy","halfCauchy"), tau = 1, glmnetid = 0,
                      burn = 500, Total_itr = 1000, thin = 1, L1 = 30, fixed.var = 100, acl = 0.6, acu = 0.8){
  pb <- txtProgressBar(min = 0, max = Total_itr, style = 3)
  method.tau = match.arg(method.tau)
  
  itr <- 0
  ard <- 0
  n   <- length(Y)
  p   <- ncol(X)
  if(is.null(Z)){Z <- matrix(rep(0, n), n, 1)}
  k  <- ncol(Z)
  theta <- rnorm(ncol(Z))
  beta <- rep(0,p)
  
  if(glmnetid){
    designmat <- cbind(X, Z)
    
    lambda <- cv.glmnet(designmat, Y, penalty.factor = c(rep(1, p), rep(0, k)))
    result <- glmnet(designmat, Y, lambda = lambda$lambda.min, penalty.factor = c(rep(1, p), rep(0, k)))
    
    beta  <- result$beta[1:p] 
    theta <- result$beta[1:k + p]
  }
  
  lambda=rep(1,p);
  bsigma <- tau * lambda
  sd <- 0.001
  beta_p   <- list()
  theta_p  <- list()
  lambda_p <- list()
  tau_p    <- list()
  while(itr < Total_itr) {
    itr <- itr + 1
    sigma <- sqrt(1 / rgamma(1, n / 2 + 0.1, sum((Y-X %*%beta - Z %*% theta)^2) / 2 + 0.1))
    y <- Y - Z %*% theta
    file <- try(temp  <- HMClin(Ulin, grad_Ulin, epsilon = sd, L = L1, beta, ard, y, X, sigma, bsigma), silent = T)
    if (class(file) == "try-error"){
      file <- try(temp  <- HMClin(Ulin, grad_Ulin, epsilon = sd, L = 1, beta, ard, y, X, sigma, bsigma), silent = T)
      if (class(file) == "try-error"){
        temp <- list(up = beta, ard = ard)
      }
    }
    
    beta <- temp$up
    ard  <- temp$ard
    
    theta.mean <- t(Z) %*% (Y - X %*% beta) / sigma ^ 2
    theta.var  <- solve(crossprod(Z) / sigma ^ 2 + diag(length(theta)) / fixed.var)
    theta.var  <- (theta.var + t(theta.var)) / 2
    theta      <- array(rmvnorm(1, theta.var %*% theta.mean, theta.var))
    
    
    eta = 1/(lambda^2)
    upsi = stats::runif(p,0,1/(1+eta))
    tempps = beta^2/(2*tau^2)
    ub = (1-upsi)/upsi
    
    Fub = 1 - exp(-tempps*ub) 
    Fub[Fub < (1e-4)] = 1e-4;  
    up = stats::runif(p,0,Fub)
    eta = -log(1-up)/tempps
    lambda = 1/sqrt(eta);
    
    
    if(method.tau == "halfCauchy"){
      tempt = sum((beta/lambda)^2)/(2)
      et = 1/tau^2
      utau = stats::runif(1,0,1/(1+et))
      ubt = (1-utau)/utau
      Fubt = stats::pgamma(ubt,(p+1)/2,scale=1/tempt)
      Fubt = max(Fubt,1e-8)
      ut = stats::runif(1,0,Fubt)
      et = stats::qgamma(ut,(p+1)/2,scale=1/tempt)
      tau = 1/sqrt(et)
    }
    
    if(method.tau == "truncatedCauchy"){
      tempt = sum((beta/lambda)^2)/(2)
      et = 1/tau^2
      utau = stats::runif(1,0,1/(1+et))
      ubt_1=1
      ubt_2 = min((1-utau)/utau,p^2)
      Fubt_1 = stats::pgamma(ubt_1,(p+1)/2,scale=1/tempt)
      Fubt_2 = stats::pgamma(ubt_2,(p+1)/2,scale=1/tempt)
      ut = stats::runif(1,Fubt_1,Fubt_2)
      et = stats::qgamma(ut,(p+1)/2,scale=1/tempt)
      tau = 1/sqrt(et)
    }
    bsigma <- tau * lambda
    
    if(itr %% 100 == 0){
      ar <- ard/ (itr)
      if(ar<acl){sd <- sd * (.5)}
      if(ar>acu){sd <- sd * (5)}}
    
    if(itr > burn){
      if((itr - burn) %% thin == 0){
        beta_p[[(itr - burn) / thin]]  <- beta
        theta_p[[(itr - burn) / thin]] <- theta
        lambda_p[[(itr - burn) / thin]] <- lambda
        tau_p[[(itr - burn) / thin]] <- tau
      }
    }
    Sys.sleep(0.1)
    # update progress bar
    setTxtProgressBar(pb, itr)
  }
  close(pb)
  out <- list(beta_post = beta_p, lambda_post = lambda_p, 
              tau_post = tau_p, theta_post = theta_p)
  if(is.null(Z)){out <- list(beta_post = beta_p, lambda_post = lambda_p, 
                             tau_post = tau_p)}
  return(out)
}

#################################Function HSIM##########################
#' @title The function to fit the model Y = X'beta + Z'theta using Dirichlet-Laplace prior on beta
#' @description Takes the response variable, explanatory variables (high and low dimensional) and some
#' other tuning parameters and spits out MCMC samples of beta and eta and other hyper parameters 
#' @references Bhattacharya, Anirban, et al. "Dirichlet-Laplace priors for optimal shrinkage.
#' " Journal of the American Statistical Association 110.512 (2015): 1479-1490.
#'
#' @param Y response variable
#' @param X is high dimensional explanatory variable
#' @param Z is low dimensional explanatory variable
#' @param ap is the tuning parameter 'a' from the prior setup
#' @param glmnetid is the indicator variable if initialization is done via LASSO optimization
#' @param burn is the number of burn-in samples
#' @parma Total_itr is the total number of samples
#' @param thin is the integer that is thinning parameter of MCMC chain
#' @param L1 is the leapfrog step of the HMC sampler
#' @param fixed.var is the prior variance for coefficients of B-spline
#' @param acl is the lower acceptance level of the HMC sampler
#' @param acu is the upper acceptance level of the HMC sampler

#' @return dl returns a list of the following elements \cr
#' \item{beta_post}{Posterior samples of beta}
#' \item{phi_post}{Posterior samples of phi from the DL prior}
#' \item{psi_post}{Posterior samples of psi from the DL prior}
#' \item{tau_post}{Posterior samples of tau from the DL prior}
#' \item{theta_post}{Posterior samples of theta}
#'
#'
#' @export
#' @examples
#' angl0 <- runif(49, 0, pi)
#' beta <- polrec(angl0)
#' theta <- rnorm(11)
#' X <- matrix(rnorm(5000), 100)
#' Y <- rnorm(sin(crossprod(t(X), beta)))
#' sigma0 <- 1
#' fit <- dl(Y, X)
#'

dl <- function(Y, X, Z = NULL, ap = 1 / ncol(X), glmnetid = 0,
               burn = 500, Total_itr = 1000, thin = 1, L1 = 30, fixed.var = 100, acl = 0.6, acu = 0.8){
  pb <- txtProgressBar(min = 0, max = Total_itr, style = 3)
  itr <- 0
  ard <- 0
  znull <- is.null(Z)
  n   <- length(Y)
  p   <- ncol(X)
  if(is.null(Z)){Z <- matrix(rep(0, n), n, 1)}
  k <- ncol(Z)
  theta <- rnorm(ncol(Z))
  beta <- rep(0,p)
  
  if(glmnetid){
    designmat <- cbind(X, Z)
    
    lambda <- cv.glmnet(designmat, Y, penalty.factor = c(rep(1, p), rep(0, k)))
    result <- glmnet(designmat, Y, lambda = lambda$lambda.min, penalty.factor = c(rep(1, p), rep(0, k)))
    
    beta  <- result$beta[1:p] 
    theta <- result$beta[1:k + p]
  }
  
  sd <- 0.001
  psi       <- rexp(p, 0.5)
  phi       <- rdirichlet(1, rep(ap, p))
  tau       <- rgamma(1, p*ap, 0.5)
  bsigma <- tau * phi * sqrt(psi)
  
  beta_p  <- list()
  theta_p <- list()
  psi_p   <- list()
  phi_p   <- list()
  tau_p   <- list()
  while(itr < Total_itr) {
    itr <- itr + 1
    sigma <- sqrt(1 / rgamma(1, n / 2 + 0.1, sum((Y-X %*%beta - Z %*% theta)^2) / 2 + 0.1))
    y <- Y - Z %*% theta
    file <- try(temp  <- HMClin(Ulin, grad_Ulin, epsilon = sd, L = L1, beta, ard, y, X, sigma, bsigma), silent = T)
    if (class(file) == "try-error"){
      file <- try(temp  <- HMClin(Ulin, grad_Ulin, epsilon = sd, L = 1, beta, ard, y, X, sigma, bsigma), silent = T)
      if (class(file) == "try-error"){
        temp <- list(up = beta, ard = ard)
      }
    }
    
    beta <- temp$up
    ard  <- temp$ard
    
    theta.mean <- t(Z) %*% (Y - X %*% beta) / sigma ^ 2
    theta.var  <- solve(crossprod(Z) / sigma ^ 2 + diag(length(theta)) / fixed.var)
    theta.var  <- (theta.var + t(theta.var)) / 2
    theta      <- array(rmvnorm(1, theta.var %*% theta.mean, theta.var))
    
    temp <- phi
    
    psi  <- rinvgauss(p, tau * (phi/abs(beta)))
    temp <- rgig(p, ap - 1, 1, 2*abs(beta))
    
    phi  <- temp / sum(temp)
    tau  <- rgig(1, p*ap - p, 1, 2*sum(abs(beta)/phi))
    
    bsigma <- tau * phi * sqrt(psi)
    
    if(itr %% 100 == 0){
      ar <- ard/ (itr)
      if(ar<acl){sd <- sd * (.5)}
      if(ar>acu){sd <- sd * (5)}}
    
    if(itr > burn){
      if((itr - burn) %% thin == 0){
        beta_p[[(itr - burn) / thin]]  <- beta
        theta_p[[(itr - burn) / thin]] <- theta
        phi_p[[(itr - burn) / thin]]   <- phi
        psi_p[[(itr - burn) / thin]]   <- psi
        tau_p[[(itr - burn) / thin]]   <- tau
      }
    }
    Sys.sleep(0.1)
    # update progress bar
    setTxtProgressBar(pb, itr)
  }
  close(pb)
  out <- list(beta_post = beta_p, phi_post=phi_p, psi_post=psi_p,
              tau_post = tau_p, theta_post = theta_p)
  if(znull){out <- list(beta_post = beta_p, phi_post=phi_p, psi_post=psi_p,
                        tau_post = tau_p)}
  return(out)
}

basefun <- function(j, theta, x_sp, y_sp)
{
  a_bs <- x_sp[j, ]
  b_bs <- y_sp[j, ]
  J <- ncol(a_bs)
  coef_mat <- matrix(theta, nrow = basisno)
  result <- a_bs %*% coef_mat %*% array(b_bs)
  return(result)
}

HMCtheta = function (Uth, grad_Uth, epsilon, L = 30, current_q, theta, ard, Y, X, z_sp, sigma, pr, len)
{
  q = current_q
  po = rnorm(length(q))#runif(length(q),0,pi)  # independent standard normal variates
  #po  <- c(po, runif(1,0,2*pi))
  current_p = po
  
  # Make a half step for momentum at the beginning
  
  po = po - epsilon * grad_Uth(q, theta, Y, X, z_sp, sigma, pr, len) / 2
  
  # Alternate full steps for position and momentum
  
  for (j in 1:L)
  {
    # Make a full step for the position
    
    q[1:(len - 1)] = pi - abs(q[1:(len - 1)] + epsilon * po[1:(len - 1)] - pi)
    q[len] = 2 * pi - abs(q[len] + epsilon * po[len] - 2*pi)
    # Make a full step for the momentum, except at end of trajectory
    
    if (j!=L) po = po - epsilon * grad_Uth(q, theta, Y, X, z_sp, sigma, pr, len)
  }
  
  # Make a half step for momentum at the end.
  
  po = po - epsilon * grad_Uth(q, theta, Y, X, z_sp, sigma, pr, len) / 2
  
  # Negate momentum at end of trajectory to make the proposal symmetric
  
  po = -po
  
  # Evaluate potential and kinetic energies at start and end of trajectory
  
  current_U = Uth(current_q, theta, Y, X, z_sp, sigma, pr, len)
  current_K = sum(current_p^2) / 2
  proposed_U = Uth(q, theta, Y, X, z_sp, sigma, pr, len)
  proposed_K = sum(po^2) / 2
  
  # Accept or reject the state at end of trajectory, returning either
  # the position at the end of the trajectory or the initial position
  
  R <- exp(current_U-proposed_U+current_K-proposed_K)
  if(is.na(R) == T || is.nan(R) == T){R = 1}
  if (runif(1) < R)
  {
    ard <- ard + 1
    return (list(up=q, ard = ard))  # accept
  }
  else
  {
    return (list(up=current_q, ard = ard))  # reject
  }
}

Uth <- function(angl, theta, Y, X, z_sp, sigma, pr, len, sh1 = 0.1, sh2 = 10){
  beta <- polrec(angl)
  n<- length(Y)
  x = rowSums(X *matrix(rep(beta, n), nrow = n, byrow = T))
  x_sp <- bsplineS(x, breaks = seq( - 1, 1, 1/knot), 4, 0)
  
  a0 <- mcmapply(1:n, FUN = basefun, MoreArgs = list(theta = theta, x_sp, z_sp))
  Fn <- array(a0)
  thetap <- angl
  thetap[1:(len - 1)] <- (pi / 2 - abs(angl[1:(len-1)]-pi/2))/(pi/2)
  temp <- thetap[len]
  temp <- temp - pi/2*(temp > pi/2) - pi/2*(temp > pi) - pi/2*(temp > 3*pi/2)
  temp <- (pi/4 - abs(temp-pi/4))/(pi/4)
  thetap[len] <- temp
  pr1 <- rep(sh1, len)
  pr2 <- rep(sh2, len)
  prior2 <- (1-pr)*pr1 + (pr) * 1
  prior1 <- (1-pr)*pr2 + (pr) * 1
  ret <- sum((Y - Fn)^2/(2*sigma^2)) - sum(dbeta(thetap, prior1, prior2, log = T))
  return(ret)
}

grad_Uth <- function(angl, theta, Y, X, z_sp, sigma, pr, len, sh1 = 0.1, sh2 = 10){
  beta <- polrec(angl)
  n <- length(Y)
  
  x = rowSums(X1s *matrix(rep(beta, n), nrow = n, byrow = T))
  x_sp <- bsplineS(x, breaks = seq( - 1, 1, 1/knot), 4, 0)
  x_spder <- bsplineS(x, breaks = seq( - 1, 1, 1/knot), 4, 1)
  a0 <- mcmapply(m[, 1], m[, 2], FUN = basefun, MoreArgs = list(theta = theta, x_sp, z_sp))
  
  a0der <- mcmapply(1:n, FUN = basefun, MoreArgs = list(theta = theta, x_spder, z_sp))
  
  Fn <- array(a0)
  Fnder <- array(a0der)
  thetap <- angl
  thetap[1:(len - 1)] <- (pi / 2 - abs(angl[1:(len-1)]-pi/2))/(pi/2)
  temp <- thetap[len]
  temp <- temp - pi/2*(temp > pi/2) - pi/2*(temp > pi) - pi/2*(temp > 3*pi/2)
  temp <- (pi/4 - abs(temp-pi/4))/(pi/4)
  thetap[len] <- temp
  pr1 <- rep(sh1, len)
  pr2 <- rep(sh2, len)
  prior2 <- (1-pr)*pr1 + (pr) * 1
  prior1 <- (1-pr)*pr2 + (pr) * 1
 
  temp <- ((logy - Fn)*(-Fnder)/(sigma^2))
  
  X1stemp  <- (X *matrix(rep(beta, n), nrow = n, byrow = T))
  X1stemp1 <- t(apply(X1stemp[, ncol(X1stemp):1], 1, cumsum))
  X1stemp1 <- X1stemp1[, ncol(X1stemp):2] - X1stemp[, 1:(ncol(X1stemp)-1)]
  X1stemp1 <- X1stemp1 * matrix(rep(1/tan(angl), n), nrow = n, byrow = T)
  X1stemp1 <- X1stemp1 - (X1s[, 1:len] * matrix(rep(beta[1:len] * tan(angl), n), nrow = n, byrow = T))
  
  ret <- colSums(X1stemp1*temp) - (prior1-1)/thetap + (prior2-1)/(1-thetap)
  return(ret)
}

HMCkap = function (Uth, grad_Uth, epsilon, L = 30, current_q, theta, ard, Y, x_sp, Z, sigma, len)
{
  q = current_q
  po = rnorm(length(q))#runif(length(q),0,pi)  # independent standard normal variates
  #po  <- c(po, runif(1,0,2*pi))
  current_p = po
  
  # Make a half step for momentum at the beginning
  
  po = po - epsilon * grad_Uth(q, theta, Y, x_sp, Z, sigma, len) / 2
  
  # Alternate full steps for position and momentum
  
  for (j in 1:L)
  {
    # Make a full step for the position
    
    q[1:(len - 1)] = pi - abs(q[1:(len - 1)] + epsilon * po[1:(len - 1)] - pi)
    q[len] = 2 * pi - abs(q[len] + epsilon * po[len] - 2*pi)
    # Make a full step for the momentum, except at end of trajectory
    
    if (j!=L) po = po - epsilon * grad_Uth(q, theta, Y, x_sp, Z, sigma, len)
  }
  
  # Make a half step for momentum at the end.
  
  po = po - epsilon * grad_Uth(q, theta, Y, x_sp, Z, sigma, len) / 2
  
  # Negate momentum at end of trajectory to make the proposal symmetric
  
  po = -po
  
  # Evaluate potential and kinetic energies at start and end of trajectory
  
  current_U = Uth(current_q, theta, Y, x_sp, Z, sigma, len)
  current_K = sum(current_p^2) / 2
  proposed_U = Uth(q, theta, Y, x_sp, Z, sigma, len)
  proposed_K = sum(po^2) / 2
  
  # Accept or reject the state at end of trajectory, returning either
  # the position at the end of the trajectory or the initial position
  R <- exp(current_U-proposed_U+current_K-proposed_K)
  if(is.na(R) == T || is.nan(R) == T){R = 1}
  if (runif(1) < R)
  {
    ard <- ard + 1
    return (list(up=q, ard = ard))  # accept
  }
  else
  {
    return (list(up=current_q, ard = ard))  # reject
  }
}

Ukap <- function(angl, theta, Y, x_sp, Z, sigma, len){
  eta <- polrec(angl)
  n <- length(Y)  
  
  z = rowSums(Z *matrix(rep(eta, n), nrow = n, byrow = T))
  z_sp <- bsplineS(z, breaks = seq( - 1, 1, 1/knot), 4, 0)
  
  a0 <- mcmapply(1:n, FUN = basefun, MoreArgs = list(theta = theta, x_sp, z_sp))
  
  Fn <- array(a0)
  thetap <- angl
  thetap[1:(len - 1)] <- (pi / 2 - abs(angl[1:(len-1)]-pi/2))/(pi/2)
  temp <- thetap[len]
  temp <- temp - pi/2*(temp > pi/2) - pi/2*(temp > pi) - pi/2*(temp > 3*pi/2)
  temp <- (pi/4 - abs(temp-pi/4))/(pi/4)
  thetap[len] <- temp
  
  prior1 <- rep(1, len)
  prior2 <- rep(1, len)
  ret <- sum((logy - Fn)^2/(2*sigma^2)) - sum(dbeta(thetap, prior1, prior2, log = T))
  return(ret)
}

grad_Ukap <- function(angl, theta, Y, x_sp, Z, sigma, len){
  eta <- polrec(angl)
  n   <- length(Y)
  z = rowSums(Z1s *matrix(rep(eta, n), nrow = n, byrow = T))
  z_sp <- bsplineS(z, breaks = seq( - 1, 1, 1/knot), 4, 0)
  z_spder <- bsplineS(z, breaks = seq( - 1, 1, 1/knot), 4, 1)
  
  a0 <- mcmapply(1:n, FUN = basefun, MoreArgs = list(theta = theta, x_sp, z_sp))
  
  a0der <- mcmapply(m[, 1], m[, 2], FUN = basefun, MoreArgs = list(theta = theta, x_sp, z_spder))
  
  Fn <- array(a0)
  Fnder <- array(a0der)
  thetap <- angl
  thetap[1:(len - 1)] <- (pi / 2 - abs(angl[1:(len-1)]-pi/2))/(pi/2)
  temp <- thetap[len]
  temp <- temp - pi/2*(temp > pi/2) - pi/2*(temp > pi) - pi/2*(temp > 3*pi/2)
  temp <- (pi/4 - abs(temp-pi/4))/(pi/4)
  thetap[len] <- temp
  prior1 <- rep(1, len)
  prior2 <- rep(1, len)
  
  temp <- ((logy - Fn)*(-Fnder)/(sigma^2))
  
  Z1stemp  <- (Z *matrix(rep(eta, n), nrow = n, byrow = T))
  Z1stemp1 <- t(apply(Z1stemp[, ncol(Z1stemp):1], 1, cumsum))
  Z1stemp1 <- Z1stemp1[, ncol(Z1stemp):2] - Z1stemp[, 1:(ncol(Z1stemp)-1)]
  Z1stemp1 <- Z1stemp1 * matrix(rep(1/tan(angl), n), nrow = n, byrow = T)
  Z1stemp1 <- Z1stemp1 - (Z1s[, 1:len] * matrix(rep(beta[1:len] * tan(angl), n), nrow = n, byrow = T))
  
  ret <- colSums(Z1stemp1*temp) - (prior1-1)/thetap + (prior2-1)/(1-thetap)
  return(ret)
}

shi <- function(x, y){
  r <- sapply(1:J, function(j){array(tcrossprod(x[j, ], y[j, ]))})
  return(r)
}

#################################Function HSIM##########################
#' @title The function to fit the model Y = f(X'beta, Z'eta)
#' @description Takes the response variable, explanatory variables (high and low dimensional), B-spline coefficients corresponding to
#' the non-parametric modelling of 'f', current value of beta, some
#' other tuning parameters and spits out MCMC samples of polar angles of beta and eta and B-spline coefficients 
#' @references Roy, A., Ghosal, S. and Choudhury K.R.
#'     "High dimensional Single Index Bayesian Modeling of the Brain Atrophy over time" arXiv 1712.06743
#'
#' @param Y response variable
#' @param X is high dimensional explanatory variable
#' @param Z is low dimensional explanatory variable
#' @param sh1 is the smaller shape parameter of spike distribution
#' @param sh1 is the larger shape parameter of spike distribution
#' @param prq is the tuning parameter q, from the paper
#' @param glmnetid is the indicator variable if initialization is done via LASSO optimization
#' @param basisno is the number of B-spline coefficients
#' @param burn is the number of burn-in samples
#' @parma Total_itr is the total number of samples
#' @param thin is the integer that is thinning parameter of MCMC chain
#' @param L1 is the leapfrog step of the HMC sampler
#' @param prior.var is the prior variance for coefficients of B-spline
#' @param acl is the lower acceptance level of the HMC sampler
#' @param acu is the upper acceptance level of the HMC sampler


#' @return hsim returns a list of the following elements \cr
#' \item{angl1_post}{Posterior samples of polar angles of beta}
#' \item{angl2_post}{Posterior samples of polar angles of eta}
#' \item{model}{Posterior samples of model indicators i.e. 'gamma' from the paper}
#' \item{theta_post}{Posterior samples of coefficients of B-spline}
#'
#'
#' @export
#' @examples
#' angl0 <- runif(99, 0, pi)
#' beta <- polrec(angl0)
#' X <- matrix(rnorm(5000), 50)
#' X <- X / sqrt(rowSums(X^2))
#' Y <- rnorm(sin(crossprod(t(X), beta)))
#' sigma0 <- 1
#' fit <- hsim(Y, X)
#'

hsim <- function(Y, X, Z = NULL, sh1 = 0.1, sh2 = 10, prq = 0.01, glmnetid = 0,
                 basisno = round((length(y)/log(length(y)))^(2/3)),burn = 500, Total_itr = 1000, 
                 thin = 1, L1 = 30, prior.var = 100, acl = 0.6, acu = 0.8){
  pb <- txtProgressBar(min = 0, max = Total_itr, style = 3)
  znull <- is.null(Z)
  xnull <- is.null(X)
  
  if(basisno%%2 == 0){basisno <- basisno+1}
  knot <- (basisno - 3)/2
  
  bhalf <- floor(basisno/2)
  A <- matrix(1:(bhalf+1)^2, bhalf+1, bhalf+1)
  A <- cbind(A, A[, bhalf:1])
  A <- rbind(A, A[bhalf:1, ])
  
  ind <- array(A)
  
  ind <- cbind(1:length(ind), ind)
  
  K <- matrix(0, length(ind[, 1]), (bhalf+1)^2)
  
  K[ind] <- 1
  
  thetar <- rnorm((bhalf+1)^2, mean = 2)
  theta <- K %*% thetar
  
  n   <- length(Y)
  p   <- ncol(X)
  
  if(is.null(Z)){Z <- matrix(rep(0, 2*n), n, 2)}
  if(is.null(X)){X <- matrix(rep(0, 2*n), n, 2)}
  k <- ncol(Z)
  
  len1 = p - 1
  len2 = k - 1
  sd <- 0.001
  theta <- rnorm(ncol(Z))
  beta <- rnorm(p)
  
  if(glmnetid){
    designmat <- cbind(X, Z)
    
    lambda <- cv.glmnet(designmat, Y, penalty.factor = c(rep(1, p), rep(0, k)))
    result <- glmnet(designmat, Y, lambda = lambda$lambda.min, penalty.factor = c(rep(1, p), rep(0, k)))
    
    beta  <- result$beta[1:p] 
    theta <- result$beta[1:k + p]
  }
  
  beta <- beta / sqrt(sum(beta^2))
  eta <- eta / sqrt(sum(eta^2))
  
  angl1 <- (rect2polar(beta)$phi ) %% (2*pi)
  angl1[1:(len1-1)] <- angl1[1:(len1-1)] %% (pi)
  
  angl2 <- rect2polar(eta)$phi %% (2*pi)
  
  angl1_p <- list()
  angl2_p <- list()
  theta_p <- list()
  pr_p    <- list()
  
  prp <- rbinom(len, 1, prq)
  
  x = rowSums(X *matrix(rep(beta, n), nrow = n, byrow = T))
  x_sp <- bsplineS(x, breaks = seq( - 1, 1, 1/knot), 4, 0)
  
  z = rowSums(Z *matrix(rep(eta, n), nrow = n, byrow = T))
  z_sp <- bsplineS(z, breaks = seq( - 1, 1, 1/knot), 4, 0)
  
  itr <- 0
  ard1 <- 0
  ard2 <- 0
  while(itr < Total_itr) {
    itr <- itr + 1
    a0  <- mcmapply(1:n, FUN = basefun, MoreArgs = list(theta = theta, x_sp, z_sp))
    
    sigma <- sqrt(1 / rgamma(1, n / 2 + 0.1, sum((Y-array(a0))^2) / 2 + 0.1))
    
    file <- try(temp  <- HMC(Uth, grad_Uth, epsilon = sd1, L = L1, angl1, theta, ard1, Y, X, z_sp, sigma, pr, len1), silent = T)
    if (class(file) == "try-error"){
      file <- try(temp  <- HMC(Uth, grad_Uth, epsilon = sd1, L = 1, angl1, theta, ard1, Y, X, z_sp, sigma, pr, len1), silent = T)
      if (class(file) == "try-error"){
        temp <- list(up = angl1, ard = ard1)
      }
    }
    
    angl1 <- temp$up
    ard1  <- temp$ard
    
    beta <- polrec(angl1)#betau$beta
    
    thetap <- angl1
    thetap[1:(len1 - 1)] <- (pi / 2 - abs(angl1[1:(len1-1)]-pi/2))/(pi/2)
    temp <- thetap[len1]
    temp <- temp - pi/2*(temp > pi/2) - pi/2*(temp > pi) - pi/2*(temp > 3*pi/2)
    temp <- (pi/4 - abs(temp-pi/4))/(pi/4)
    thetap[len] <- temp
    
    prp <- prq / (prq + (1 - prq)*dbeta(thetap, sh2, sh1))
    
    pr <- rbinom(len1, 1, prp)
    
    x = rowSums(X *matrix(rep(beta, n), nrow = n, byrow = T))
    x_sp <- bsplineS(x, breaks = seq( - 1, 1, 1/knot), 4, 0)
    
    file <- try(temp  <- HMC(Ukap, grad_Ukap, epsilon = sd2, L = L1, angl2, theta, ard2, Y, x_sp, z, sigma, len2), silent = T)
    if (class(file) == "try-error"){
      file <- try(temp  <- HMC(Ukap, grad_Ukap, epsilon = sd2, L = 1, angl2, theta, ard2, Y, x_sp, z, sigma, len2), silent = T)
      if (class(file) == "try-error"){
        temp <- list(up = angl2, ard = ard2)
      }
    }
    
    angl2 <- temp$up
    ard2  <- temp$ard
    
    eta <- polrec(angl2)
    
    z = rowSums(Z *matrix(rep(eta, n), nrow = n, byrow = T))
    z_sp <- bsplineS(z, breaks = seq( - 1, 1, 1/knot), 4, 0)
    
    shimat <- shi(x_sp, z_sp)
    
    B <- matrix(0, basisno^2, basisno^2)
    for(j in 1:n){
      B <- B + tcrossprod(shimat[, j])
    }
    
    D <- (1 / (sigma ^ 2)) * B + diag(basisno^2) / (prior.var)
    
    theta.var <- solve(t(K)%*%D%*%K)
    theta.var <- (theta.var + t(theta.var)) / 2
    
    temp <- matrix(rep(Y/ (sigma ^ 2), basisno^2), nrow = basisno^2, byrow = T)
    thetai_mean <- crossprod(theta.var, t(K)%*%rowSums(shimat * temp))
    thetar <- rmvnorm(1, thetai_mean, theta.var)
    
    theta <- K %*% array(thetar)
    
    if(itr %% 100 == 0){
      ar <- ard1 / (itr)
      if(ar<acl){sd1 <- sd1 * (.5)}
      if(ar>acu){sd1 <- sd1 * (5)}}
    
    if(itr %% 100 == 0){
      ar <- ard2 / (itr)
      if(ar<acl){sd2 <- sd2 * (.5)}
      if(ar>acu){sd2 <- sd2 * (5)}}
    
    if(itr > burn){
      if((itr - burn) %% thin == 0){
        angl1_p[[(itr - burn) / thin]] <- angl1
        angl2_p[[(itr - burn) / thin]] <- angl2
        pr_p[[(itr - burn) / thin]]    <- pr
        theta_p[[(itr - burn) / thin]] <- theta
      }
    }
    Sys.sleep(0.1)
    # update progress bar
    setTxtProgressBar(pb, itr)
  }
  close(pb)
  out <- list(angl1_post = angl1_p, angl2_post = angl2_p, model = pr_p, theta_post = theta_p)
  if(znull){out <- list(angl1_post = angl1_p, model = pr_p, theta_post = theta_p)}
  if(xnull){out <- list(angl2_post = angl2_p, theta_post = theta_p)}
  return(out)
}